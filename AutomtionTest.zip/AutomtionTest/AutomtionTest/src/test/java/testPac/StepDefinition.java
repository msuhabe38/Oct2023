package testPac;

import impl.RegisterNewUser;
import impl.ShopNPayment;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class StepDefinition{

    RegisterNewUser registerPage = new RegisterNewUser();
    ShopNPayment shopPay = new ShopNPayment();


    @Given("^User is in HomePage$")
    public void user_is_in_home_page() {
        registerPage.verifyHomePage();
    }
    @Then("Register new user by entering details")
    public void register_new_user_by_entering_details(DataTable dataTable) throws InterruptedException {
        registerPage.clickRegisterButton();
        registerPage.clickContinueButton();
        registerPage.register(dataTable);

    }
    @And("Verify user {string} is able to login Successfully")
    public void verify_user_is_able_to_login_successfully(String val) {
        registerPage.verifyUserLoggedIn(val);
    }


    @And("Add a product {string} to cart")
    public void add_a_product_to_cart(String product) {
        shopPay.clickCategoryMenu();
        shopPay.clickProduct(product);
        shopPay.addProductToCart();
    }

    @And("Proceed to checkout Page {string}")
    public void proceed_to_checkout_page(String val) {
        shopPay.clickCart(val);
        shopPay.clickCheckout();
    }

    @And("Validate product {string} in Payments Page")
    public void validate_product_in_payments_page(String val) {
        shopPay.confirmProducts(val);
        shopPay.confirmOrderPlaced();
    }
}
