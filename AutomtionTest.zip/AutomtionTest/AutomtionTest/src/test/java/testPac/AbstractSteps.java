package testPac;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;

public class AbstractSteps {

    public static WebDriver driver;
    public ExtentReports reports;

    public ExtentSparkReporter extentSpRpt;
    public static ExtentTest logger;

    public static WebDriver getDriver(){
        if(driver==null) {
            driver = new ChromeDriver();
        }
        return driver;
    }

    @Before
    public void launch(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\chromedriver\\chromedriver.exe");

        getDriver().manage().window().maximize();
        System.out.println(getDriver().getTitle());
        getDriver().get("https://automationteststore.com/");
        startTest();

    }

    @After
    public void terminate(){
        getDriver().quit();
        reports.flush();
    }

    public void startTest(){

        reports = new ExtentReports();
        extentSpRpt = new ExtentSparkReporter(new File(System.getProperty("user.dir") + "\\Reports\\extent-report.html"));
        reports.attachReporter(extentSpRpt);
        logger = reports.createTest("Automation Test Store");
    }


}
