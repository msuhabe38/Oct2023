package impl;

import com.aventstack.extentreports.Status;
import io.cucumber.datatable.DataTable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import testPac.AbstractSteps;

import java.time.Duration;

public class RegisterNewUser extends AbstractSteps{

    public void verifyHomePage(){

        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[text()='Login or register']")));
        if(getDriver().getTitle().equals("A place to practice your automation skills!")){
            logger.log(Status.PASS,"Home Page Loaded Successfully");
        }else{
            logger.log(Status.FAIL,"Home Page Not Loaded");
        }
    }

    public void clickRegisterButton(){
        WebElement loginElem = getDriver().findElement(By.xpath("//a[text()='Login or register']"));
        loginElem.click();
        logger.log(Status.PASS,"Clicked on Login or Register Button");
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'newcustomer')]/h2")));
    }

    public void clickContinueButton(){
        WebElement ContinueBtn = getDriver().findElement(By.xpath("//button[@title='Continue']"));
        ContinueBtn.click();
        logger.log(Status.PASS,"Clicked on Continue Button");
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("AccountFrm_firstname")));
    }

    public void register(DataTable dataTable) throws InterruptedException {

        WebElement fName = getDriver().findElement(By.id("AccountFrm_firstname"));
        WebElement lName = getDriver().findElement(By.id("AccountFrm_lastname"));
        WebElement eMail = getDriver().findElement(By.id("AccountFrm_email"));
        WebElement addr1 = getDriver().findElement(By.id("AccountFrm_address_1"));
        WebElement city = getDriver().findElement(By.id("AccountFrm_city"));
        WebElement zone = getDriver().findElement(By.id("AccountFrm_zone_id"));

        WebElement pstalCode = getDriver().findElement(By.id("AccountFrm_postcode"));
        WebElement country = getDriver().findElement(By.id("AccountFrm_country_id"));
        WebElement loginName = getDriver().findElement(By.id("AccountFrm_loginname"));
        WebElement loginPswd = getDriver().findElement(By.id("AccountFrm_password"));
        WebElement ConfirmPswd = getDriver().findElement(By.id("AccountFrm_confirm"));
        WebElement AgreeCheckbox = getDriver().findElement(By.id("AccountFrm_agree"));
        WebElement ContinueBtn = getDriver().findElement(By.xpath("//button[@title='Continue']"));



        fName.sendKeys(getData(dataTable,"FirstName"));
        lName.sendKeys(getData(dataTable,"LastName"));
        eMail.sendKeys(getData(dataTable,"Email"));
        logger.log(Status.PASS,"Added FirstName, Lastname and Email details");
        addr1.sendKeys(getData(dataTable,"Addr1"));
        city.sendKeys(getData(dataTable,"City"));
        Thread.sleep(2000);
        Select countrySelect = new Select(country);
        countrySelect.selectByIndex(2);

        Thread.sleep(2000);
        Select zoneSelect = new Select(zone);
        zoneSelect.selectByIndex(2);

        pstalCode.sendKeys(getData(dataTable,"Zip"));

        logger.log(Status.PASS,"Added Address, City, State, Zip and Country details");

        Thread.sleep(2000);
        loginName.sendKeys(getData(dataTable,"LoginName"));
        Thread.sleep(2000);
        loginPswd.sendKeys("Daisy4532");
        Thread.sleep(2000);
        ConfirmPswd.sendKeys("Daisy4532");

        logger.log(Status.PASS,"Added Authentcation details");
        AgreeCheckbox.click();
        Thread.sleep(2000);
        ContinueBtn.click();

        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='maintext']")));
        WebElement verifyAccountCreation = getDriver().findElement(By.xpath("//span[@class='maintext']"));
        if(verifyAccountCreation.getText().trim().equals("YOUR ACCOUNT HAS BEEN CREATED!")){
            logger.log(Status.PASS,"Account Created Successfully");
        }else{
            logger.log(Status.FAIL,"Account Not Created");
        }
    }

    private String getData(DataTable dataTable, String key){
        return dataTable.asMaps().get(0).get(key);

    }

    public void verifyUserLoggedIn(String val){
        WebElement getName = getDriver().findElement(By.xpath("//div[contains(text(),'Welcome back')]"));
        if(getName.getText().contains(val)){
            logger.log(Status.PASS,"User Name displayed correctly after creating New user");
        }else{
            logger.log(Status.FAIL,"User Name not displayed correctly after creating New user");
        }
    }

}
